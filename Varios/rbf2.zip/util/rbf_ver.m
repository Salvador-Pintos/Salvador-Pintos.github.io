%
% Prints information about the current RBF package.
%
fprintf('---------------------------------------------------------\n')
fprintf('Matlab Routines for Radial Basis Function Neural Networks\n')
fprintf('  Version 2.2, 1999/06/30\n')
fprintf('  Updates from www.anc.ed.ac.uk/~mjo/rbf.html\n')
fprintf('  Bug reports to Mark Orr (mark@anc.ed.ac.uk)\n')
fprintf('---------------------------------------------------------\n')
